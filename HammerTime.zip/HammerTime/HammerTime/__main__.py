from .game import run


def main():
    run()
