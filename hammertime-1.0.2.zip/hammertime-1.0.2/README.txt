===========
Hammer Time
===========

A point-and-click game by Ivan Hromada.

Installing and Running
----------------------

You will need Python 3 and Pygame. I hope the exe works!

To run game from window console, change directory to 
HammerTime folder and type: run_HT.exe

Playing
-------

Control the hammer with your mouse and left-click to hit 
the squirrel. You have to be fast or you'll miss the 
squirrel. You only have six chances to miss. The high
score will be shown on the start screen.

Credit
------

Story and Programming -
   by Ivan Hromada

Art - 
   Sourced from http://opengameart.org

   "forest2.png" (original: "swamp.png") by Dylan Squires

Music -
   Sourced from http://freemusicarchive.org/
   
   "<Title>" by <artist>




